import { Component } from '@angular/core';

@Component({
  selector: 'app-check-your-fridge',
  standalone: true,
  imports: [],
  templateUrl: './check-your-fridge.component.html',
  styleUrl: './check-your-fridge.component.css'
})
export class CheckYourFridgeComponent {

}
